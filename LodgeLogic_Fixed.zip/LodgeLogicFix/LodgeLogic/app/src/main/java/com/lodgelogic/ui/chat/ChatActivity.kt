package com.lodgelogic.ui.chat

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.ChatMessage
import com.lodgelogic.databinding.ActivityChatBinding
import com.lodgelogic.databinding.ItemMessageReceivedBinding
import com.lodgelogic.databinding.ItemMessageSentBinding
import com.lodgelogic.utils.NotificationHelper
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var sessionManager: SessionManager
    private var landlordId   = -1
    private var landlordName = ""
    private var listingId    = -1
    private var listingTitle = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        landlordId   = intent.getIntExtra("landlord_id",   -1)
        landlordName = intent.getStringExtra("landlord_name")  ?: "Landlord"
        listingId    = intent.getIntExtra("listing_id",    -1)
        listingTitle = intent.getStringExtra("listing_title")  ?: ""

        val db = AppDatabase.getDatabase(this)

        binding.tvLandlordName.text  = landlordName
        binding.tvListingTitle.text  = listingTitle
        binding.btnBack.setOnClickListener { finish() }

        val chatAdapter = ChatAdapter(sessionManager.getUserId())
        val layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.rvMessages.layoutManager = layoutManager
        binding.rvMessages.adapter = chatAdapter

        db.chatDao().getConversationForListing(sessionManager.getUserId(), listingId)
            .observe(this) { messages ->
                chatAdapter.submitList(messages) {
                    if (messages.isNotEmpty())
                        binding.rvMessages.smoothScrollToPosition(messages.size - 1)
                }
            }

        binding.btnSend.setOnClickListener {
            val text = binding.etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            val myId    = sessionManager.getUserId()
            val message = ChatMessage(
                senderId   = myId,
                receiverId = landlordId,
                listingId  = listingId,
                message    = text
            )
            binding.etMessage.setText("")

            lifecycleScope.launch {
                db.chatDao().insert(message)
                delay(2000L)
                val replies = listOf(
                    "Thank you for your interest! The room is still available.",
                    "Yes, the deposit confirms your booking. When would you like to move in?",
                    "I can arrange a viewing this Saturday. Does that work for you?",
                    "All utilities are included in the monthly rent.",
                    "Please send your student ID and I'll prepare the lease agreement."
                )
                val autoReply = ChatMessage(
                    senderId   = landlordId,
                    receiverId = myId,
                    listingId  = listingId,
                    message    = replies.random()
                )
                db.chatDao().insert(autoReply)
                NotificationHelper.showNewMessageNotification(
                    this@ChatActivity, landlordName, autoReply.message
                )
            }
        }
    }

    // ── Adapter ──────────────────────────────────────────────────────────────

    class ChatAdapter(private val currentUserId: Int) :
        ListAdapter<ChatMessage, RecyclerView.ViewHolder>(DIFF) {

        companion object {
            private val DIFF = object : DiffUtil.ItemCallback<ChatMessage>() {
                override fun areItemsTheSame(a: ChatMessage, b: ChatMessage) = a.id == b.id
                override fun areContentsTheSame(a: ChatMessage, b: ChatMessage) = a == b
            }
        }

        override fun getItemViewType(position: Int) =
            if (getItem(position).senderId == currentUserId) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            if (viewType == 0)
                SentViewHolder(ItemMessageSentBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else
                ReceivedViewHolder(ItemMessageReceivedBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val msg  = getItem(position)
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.timestamp))
            when (holder) {
                is SentViewHolder     -> holder.bind(msg.message, time)
                is ReceivedViewHolder -> holder.bind(msg.message, time)
            }
        }

        class SentViewHolder(private val b: ItemMessageSentBinding) :
            RecyclerView.ViewHolder(b.root) {
            fun bind(message: String, time: String) { b.tvMessage.text = message; b.tvTime.text = time }
        }

        class ReceivedViewHolder(private val b: ItemMessageReceivedBinding) :
            RecyclerView.ViewHolder(b.root) {
            fun bind(message: String, time: String) { b.tvMessage.text = message; b.tvTime.text = time }
        }
    }
}
