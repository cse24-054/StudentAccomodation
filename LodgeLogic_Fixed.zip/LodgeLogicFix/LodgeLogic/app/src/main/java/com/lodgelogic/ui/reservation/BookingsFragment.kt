package com.lodgelogic.ui.reservation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.Reservation
import com.lodgelogic.databinding.FragmentBookingsBinding
import com.lodgelogic.databinding.ItemReservationBinding
import com.lodgelogic.utils.SessionManager
import java.text.SimpleDateFormat
import java.util.*

class BookingsFragment : Fragment() {

    private var _binding: FragmentBookingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBookingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sessionManager = SessionManager(requireContext())
        val db = AppDatabase.getDatabase(requireContext())

        val adapter = ReservationAdapter()
        binding.rvReservations.adapter = adapter

        db.reservationDao().getReservationsByUser(sessionManager.getUserId())
            .observe(viewLifecycleOwner) { reservations ->
                adapter.submitList(reservations)
                binding.tvEmpty.visibility =
                    if (reservations.isEmpty()) View.VISIBLE else View.GONE
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // ── Adapter (not inner – avoids implicit reference to Fragment) ──────────

    class ReservationAdapter : ListAdapter<Reservation, ReservationAdapter.ViewHolder>(DIFF) {

        companion object {
            private val DIFF = object : DiffUtil.ItemCallback<Reservation>() {
                override fun areItemsTheSame(a: Reservation, b: Reservation) = a.id == b.id
                override fun areContentsTheSame(a: Reservation, b: Reservation) = a == b
            }
        }

        class ViewHolder(private val b: ItemReservationBinding) :
            RecyclerView.ViewHolder(b.root) {
            fun bind(r: Reservation) {
                b.tvTitle.text         = r.listingTitle
                b.tvReference.text     = "Ref: ${r.referenceNumber}"
                b.tvAmount.text        = "P${r.amount.toInt()} paid"
                b.tvStatus.text        = r.status
                b.tvPaymentMethod.text = r.paymentMethod.replace("_", " ")
                b.tvDate.text = "Reserved on " +
                    SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(r.createdAt))
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            ViewHolder(
                ItemReservationBinding.inflate(
                    LayoutInflater.from(parent.context), parent, false
                )
            )

        override fun onBindViewHolder(holder: ViewHolder, position: Int) =
            holder.bind(getItem(position))
    }
}
