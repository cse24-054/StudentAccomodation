package com.lodgelogic.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.lodgelogic.data.dao.*
import com.lodgelogic.data.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [User::class, Listing::class, Reservation::class, ChatMessage::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun reservationDao(): ReservationDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lodge_logic_db"
                )
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Seed on a background thread AFTER instance is built
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { seedDatabase(it) }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDatabase(database: AppDatabase) {
            val landlords = listOf(
                User(studentId = "L001", fullName = "Tshepo Mokobi",      email = "tshepo@landlord.bw",  password = "landlord123", role = "LANDLORD", university = "", isVerified = true),
                User(studentId = "L002", fullName = "Mrs. Sarah Molefe",  email = "sarah@landlord.bw",   password = "landlord123", role = "LANDLORD", university = "", isVerified = true),
                User(studentId = "L003", fullName = "Mr. Kabelo Sithole", email = "kabelo@landlord.bw",  password = "landlord123", role = "LANDLORD", university = "", isVerified = true),
                User(studentId = "L004", fullName = "Property Manager PH",email = "ph@landlord.bw",      password = "landlord123", role = "LANDLORD", university = "", isVerified = true),
                User(studentId = "L005", fullName = "Kefilwe Nkosi",      email = "kefilwe@landlord.bw", password = "landlord123", role = "LANDLORD", university = "", isVerified = true)
            )
            for (landlord in landlords) {
                try { database.userDao().insert(landlord) } catch (_: Exception) {}
            }

            val universities = listOf(
                "University of Botswana", "Botswana Accountancy College",
                "BIUST", "Limkokwing University", "Ba Isago University"
            )
            for (i in 1..50) {
                try {
                    database.userDao().insert(
                        User(
                            studentId = "STU${String.format("%04d", i)}",
                            fullName  = "Student $i",
                            email     = "student$i@uni.ac.bw",
                            password  = "student123",
                            role      = "STUDENT",
                            university = universities[i % universities.size],
                            isVerified = i % 3 == 0
                        )
                    )
                } catch (_: Exception) {}
            }

            val locations    = listOf("Tlokweng","Phase 2","Block 6","G-West","Broadhurst","Extension 11","Sebele","Main Mall","Phakalane","Village")
            val types        = listOf("STUDIO","SHARED","HOSTEL")
            val amenitySets  = listOf(
                "WiFi,Security,Laundry,Study Area",
                "WiFi,Security,Parking",
                "WiFi,Laundry,Shared Kitchen",
                "Security,24/7 Security,Study Area,Laundry",
                "WiFi,Security,AC,Parking",
                "WiFi,Security,Gym,Laundry",
                "WiFi,Shared Kitchen,Laundry",
                "Security,WiFi,24/7 Security"
            )
            val landlordData = listOf(
                Triple(6, "Tshepo Mokobi",      "72345678"),
                Triple(7, "Sarah Molefe",        "71234567"),
                Triple(8, "Kabelo Sithole",      "73456789"),
                Triple(9, "Property Manager PH", "74567890"),
                Triple(10,"Kefilwe Nkosi",       "75678901")
            )
            val images = listOf("listing_1","listing_2","listing_3","listing_4","listing_5")
            val titles = listOf(
                "Modern Student Studio","Executive Shared Lodge","Block 6 Cozy Loft",
                "Elite Campus Suite","Maikano Student Village","Phakalane Garden Studio",
                "Phase 2 Student Hub","Village Luxury Loft","G-West Student Nest",
                "Broadhurst Premier Studio"
            )
            val dates = listOf("2024-07-01","2024-08-01","2024-08-15","2024-09-01","2024-06-15","2024-10-01")
            val descriptions = listOf(
                "Spacious and fully furnished accommodation perfect for UB students.",
                "Secure and affordable shared lodge near campus with all utilities included.",
                "Modern loft with high-speed internet and 24/7 security.",
                "Premium student suite with excellent amenities and study environment.",
                "Purpose-built student village with great community atmosphere."
            )

            for (i in 1..50) {
                val landlord = landlordData[i % landlordData.size]
                val price    = (1500 + (i * 80) % 2500).toDouble()
                database.listingDao().insert(
                    Listing(
                        title           = "${titles[i % titles.size]} $i",
                        description     = descriptions[i % descriptions.size],
                        price           = price,
                        location        = locations[i % locations.size],
                        type            = types[i % types.size],
                        amenities       = amenitySets[i % amenitySets.size],
                        availabilityDate = dates[i % dates.size],
                        depositAmount   = price,
                        imageRes        = images[i % images.size],
                        landlordId      = landlord.first,
                        landlordName    = landlord.second,
                        landlordPhone   = landlord.third,
                        distanceFromUB  = "${String.format("%.1f", 0.5 + (i % 10) * 0.3)}km"
                    )
                )
            }
        }
    }
}
