package com.lodgelogic.ui.reservation

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.data.entities.Reservation
import com.lodgelogic.databinding.ActivityReservationBinding
import com.lodgelogic.utils.NotificationHelper
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ReservationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReservationBinding
    private lateinit var sessionManager: SessionManager
    private var listing: Listing? = null
    private var selectedPaymentMethod = "WALLET"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReservationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        val db = AppDatabase.getDatabase(this)
        val listingId = intent.getIntExtra("listing_id", -1)

        if (listingId == -1) { finish(); return }

        lifecycleScope.launch {
            listing = db.listingDao().getListingById(listingId)
            runOnUiThread { listing?.let { displayReservation(it, db) } }
        }
    }

    private fun displayReservation(l: Listing, db: AppDatabase) {
        binding.tvLodgeName.text = l.title
        binding.tvAmount.text = "P${String.format("%.2f", l.depositAmount)}"

        val walletBalance = sessionManager.getWalletBalance()
        binding.tvWalletBalance.text = "Balance: P${String.format("%.2f", walletBalance)}"

        // Payment method selection
        binding.cardWallet.setOnClickListener {
            selectedPaymentMethod = "WALLET"
            binding.cardWallet.strokeWidth = 4
            binding.cardMobileMoney.strokeWidth = 0
            binding.ivWalletCheck.visibility = View.VISIBLE
            binding.ivMobileCheck.visibility = View.GONE
        }

        binding.cardMobileMoney.setOnClickListener {
            selectedPaymentMethod = "MOBILE_MONEY"
            binding.cardMobileMoney.strokeWidth = 4
            binding.cardWallet.strokeWidth = 0
            binding.ivMobileCheck.visibility = View.VISIBLE
            binding.ivWalletCheck.visibility = View.GONE
        }

        binding.btnPayNow.setOnClickListener {
            processPayment(l, db)
        }
    }

    private fun processPayment(l: Listing, db: AppDatabase) {
        if (selectedPaymentMethod == "WALLET") {
            val balance = sessionManager.getWalletBalance()
            if (balance < l.depositAmount) {
                Toast.makeText(this, "Insufficient wallet balance", Toast.LENGTH_LONG).show()
                return
            }
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnPayNow.isEnabled = false

        lifecycleScope.launch {
            // Check if still available
            val current = db.listingDao().getListingById(l.id)
            if (current?.isReserved == true) {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    binding.btnPayNow.isEnabled = true
                    Toast.makeText(this@ReservationActivity,
                        "Sorry, this room was just reserved by another student.",
                        Toast.LENGTH_LONG).show()
                    finish()
                }
                return@launch
            }

            // Generate reference
            val ref = "LL-${System.currentTimeMillis().toString().takeLast(8)}"

            // Save reservation
            val reservation = Reservation(
                userId = sessionManager.getUserId(),
                listingId = l.id,
                listingTitle = l.title,
                amount = l.depositAmount,
                paymentMethod = selectedPaymentMethod,
                referenceNumber = ref,
                checkInDate = l.availabilityDate
            )
            db.reservationDao().insert(reservation)

            // Mark listing reserved
            db.listingDao().reserveListing(l.id, sessionManager.getUserId())

            // Deduct from wallet if applicable
            if (selectedPaymentMethod == "WALLET") {
                sessionManager.deductFromWallet(l.depositAmount)
            }

            // Send notification
            NotificationHelper.showReservationConfirmation(this@ReservationActivity, l.title, ref)

            runOnUiThread {
                binding.progressBar.visibility = View.GONE
                showReceiptDialog(l, ref)
            }
        }
    }

    private fun showReceiptDialog(l: Listing, ref: String) {
        val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        AlertDialog.Builder(this)
            .setTitle("✅ Reservation Confirmed!")
            .setMessage(
                "Lodge: ${l.title}\n" +
                "Location: ${l.location}\n" +
                "Amount Paid: P${l.depositAmount}\n" +
                "Payment: $selectedPaymentMethod\n" +
                "Reference: $ref\n" +
                "Date: $date\n\n" +
                "The landlord has been notified. Check My Bookings for details."
            )
            .setPositiveButton("View My Bookings") { _, _ ->
                finish()
            }
            .setCancelable(false)
            .show()
    }
}
