package com.lodgelogic.utils

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("lodge_logic_session", Context.MODE_PRIVATE)

    companion object {
        const val KEY_USER_ID = "user_id"
        const val KEY_USER_NAME = "user_name"
        const val KEY_USER_EMAIL = "user_email"
        const val KEY_USER_ROLE = "user_role"
        const val KEY_STUDENT_ID = "student_id"
        const val KEY_IS_LOGGED_IN = "is_logged_in"
        const val KEY_WALLET_BALANCE = "wallet_balance"

        // Search preferences
        const val KEY_PREF_LOCATION = "pref_location"
        const val KEY_PREF_MIN_PRICE = "pref_min_price"
        const val KEY_PREF_MAX_PRICE = "pref_max_price"
        const val KEY_ALERTS_ENABLED = "alerts_enabled"
    }

    fun saveLogin(id: Int, name: String, email: String, role: String, studentId: String) {
        prefs.edit().apply {
            putInt(KEY_USER_ID, id)
            putString(KEY_USER_NAME, name)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_ROLE, role)
            putString(KEY_STUDENT_ID, studentId)
            putBoolean(KEY_IS_LOGGED_IN, true)
            if (getFloat(KEY_WALLET_BALANCE, -1f) < 0) {
                putFloat(KEY_WALLET_BALANCE, 2450f) // Default wallet balance
            }
        }.apply()
    }

    fun logout() {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, false)
            remove(KEY_USER_ID)
            remove(KEY_USER_NAME)
            remove(KEY_USER_EMAIL)
            remove(KEY_USER_ROLE)
            remove(KEY_STUDENT_ID)
        }.apply()
    }

    fun isLoggedIn() = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    fun getUserId() = prefs.getInt(KEY_USER_ID, -1)
    fun getUserName() = prefs.getString(KEY_USER_NAME, "") ?: ""
    fun getUserEmail() = prefs.getString(KEY_USER_EMAIL, "") ?: ""
    fun getUserRole() = prefs.getString(KEY_USER_ROLE, "STUDENT") ?: "STUDENT"
    fun getStudentId() = prefs.getString(KEY_STUDENT_ID, "") ?: ""

    fun getWalletBalance() = prefs.getFloat(KEY_WALLET_BALANCE, 2450f).toDouble()
    fun deductFromWallet(amount: Double) {
        val current = getWalletBalance()
        prefs.edit().putFloat(KEY_WALLET_BALANCE, (current - amount).toFloat()).apply()
    }

    fun saveSearchPreferences(location: String, minPrice: Double, maxPrice: Double) {
        prefs.edit().apply {
            putString(KEY_PREF_LOCATION, location)
            putFloat(KEY_PREF_MIN_PRICE, minPrice.toFloat())
            putFloat(KEY_PREF_MAX_PRICE, maxPrice.toFloat())
        }.apply()
    }

    fun getPrefLocation() = prefs.getString(KEY_PREF_LOCATION, "") ?: ""
    fun getPrefMinPrice() = prefs.getFloat(KEY_PREF_MIN_PRICE, 1000f).toDouble()
    fun getPrefMaxPrice() = prefs.getFloat(KEY_PREF_MAX_PRICE, 5000f).toDouble()

    fun setAlertsEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ALERTS_ENABLED, enabled).apply()
    }
    fun isAlertsEnabled() = prefs.getBoolean(KEY_ALERTS_ENABLED, true)
}
