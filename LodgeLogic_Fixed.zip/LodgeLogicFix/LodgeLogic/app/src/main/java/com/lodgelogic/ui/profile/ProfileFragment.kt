package com.lodgelogic.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.lodgelogic.databinding.FragmentProfileBinding
import com.lodgelogic.ui.auth.LoginActivity
import com.lodgelogic.utils.SessionManager

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sessionManager = SessionManager(requireContext())

        binding.tvUserName.text = sessionManager.getUserName()
        binding.tvStudentId.text = "ID-${sessionManager.getStudentId()}"
        binding.tvUniversity.text = "University of Botswana"
        binding.tvWalletBalance.text = "P${String.format("%.2f", sessionManager.getWalletBalance())}"
        binding.tvPrefLocation.text = sessionManager.getPrefLocation().ifEmpty { "Not set" }
        binding.tvPrefBudget.text = "P${sessionManager.getPrefMinPrice().toInt()}–P${sessionManager.getPrefMaxPrice().toInt()}"

        binding.switchAlerts.isChecked = sessionManager.isAlertsEnabled()
        binding.switchAlerts.setOnCheckedChangeListener { _, checked ->
            sessionManager.setAlertsEnabled(checked)
        }

        binding.btnLogout.setOnClickListener {
            sessionManager.logout()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finishAffinity()
        }

        binding.btnEditPreferences.setOnClickListener {
            // Navigate to search for preference editing
            binding.tvPrefLocation.text = "Tap Search to update"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
