package com.lodgelogic.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.R
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.databinding.ItemListingBinding

class ListingAdapter(private val onItemClick: (Listing) -> Unit) :
    ListAdapter<Listing, ListingAdapter.ListingViewHolder>(DIFF_CALLBACK) {

    companion object {
        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Listing>() {
            override fun areItemsTheSame(oldItem: Listing, newItem: Listing) =
                oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Listing, newItem: Listing) =
                oldItem == newItem
        }
    }

    inner class ListingViewHolder(private val binding: ItemListingBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(listing: Listing) {
            binding.tvTitle.text = listing.title
            binding.tvPrice.text = "P${listing.price.toInt()}/mo"
            binding.tvLocation.text = "${listing.location}, Gaborone"
            binding.tvType.text = listing.type

            val amenities = listing.amenities.split(",")
            binding.tvAmenities.text = amenities.take(2).joinToString(" · ")

            if (listing.isReserved) {
                binding.tvStatus.text = "Reserved"
                binding.tvStatus.setBackgroundResource(R.drawable.bg_badge_reserved)
            } else {
                binding.tvStatus.text = "Available"
                binding.tvStatus.setBackgroundResource(R.drawable.bg_badge_available)
            }

            // Set placeholder image based on listing type
            val imageRes = when (listing.type) {
                "STUDIO" -> R.drawable.placeholder_studio
                "SHARED" -> R.drawable.placeholder_shared
                else -> R.drawable.placeholder_hostel
            }
            binding.ivListing.setImageResource(imageRes)

            binding.root.setOnClickListener { onItemClick(listing) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListingViewHolder {
        val binding = ItemListingBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ListingViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListingViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
