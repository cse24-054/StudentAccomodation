# Lodge Logic - Student Accommodation Finder
## CSE201 Mobile Application Development Assignment

### Setup Instructions

1. **Open Android Studio** (version 7 or above)
2. **Import the project**: File → Open → select the `LodgeLogic` folder
3. **Sync Gradle**: Click "Sync Now" when prompted
4. **Create AVD**: Tools → AVD Manager → Create Virtual Device
   - Select: **Nexus 5**
   - System Image: **Android 6.0 (API 23)** or higher (SDK 26+ recommended)
5. **Run the app**: Click ▶ Run button

### Default Login Credentials
- **Student**: email: `student1@uni.ac.bw` | password: `student123`
- **Landlord**: email: `tshepo@landlord.bw` | password: `landlord123`
- Or register a new account from the login screen

### App Features
- ✅ Student Registration & Login (50 pre-seeded students)
- ✅ 50 Accommodation Listings (Gaborone areas)
- ✅ Smart Filtering (price, location, type)
- ✅ Smart Alerts / Notifications (saved preferences)
- ✅ Simulated Deposit Payment (Wallet & Mobile Money)
- ✅ Room Reservation with Reference Number
- ✅ Chat between Student & Landlord (Extension Feature)
- ✅ Booking History
- ✅ Student Profile & Preferences

### Technical Stack
- **Language**: Kotlin
- **Database**: Room (SQLite)
- **Architecture**: MVVM with LiveData
- **Navigation**: Jetpack Navigation Component
- **UI**: Material Design 3
- **Min SDK**: 26 | Target SDK: 33

### Screens (5+)
1. Splash Screen
2. Login Screen
3. Register Screen
4. Home Screen (Bottom Nav)
5. Search & Filter Screen
6. Listing Detail Screen
7. Reservation / Payment Screen
8. Chat Screen
9. Bookings Screen
10. Profile Screen
