# Add project specific ProGuard rules here.
-keep class com.lodgelogic.data.entities.** { *; }
-keep class com.lodgelogic.data.dao.** { *; }
