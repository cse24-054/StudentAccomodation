package com.lodgelogic.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val studentId: String,
    val fullName: String,
    val email: String,
    val password: String,
    val university: String = "University of Botswana",
    val role: String = "STUDENT", // STUDENT or LANDLORD
    val profileImage: String = "",
    val isVerified: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
