package com.lodgelogic.ui.profile

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.data.entities.Reservation
import com.lodgelogic.databinding.FragmentProfileBinding
import com.lodgelogic.databinding.ItemReservationBinding
import com.lodgelogic.ui.auth.LoginActivity
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sessionManager = SessionManager(requireContext())
        val db = AppDatabase.getDatabase(requireContext())

        // User info
        binding.tvUserName.text      = sessionManager.getUserName()
        binding.tvStudentId.text     = "ID-${sessionManager.getStudentId()}"
        binding.tvUniversity.text    = "University of Botswana"
        binding.tvWalletBalance.text = "P${String.format("%.2f", sessionManager.getWalletBalance())}"
        binding.tvPrefLocation.text  = sessionManager.getPrefLocation().ifEmpty { "Not set" }
        binding.tvPrefBudget.text    = "P${sessionManager.getPrefMinPrice().toInt()}–P${sessionManager.getPrefMaxPrice().toInt()}"

        binding.switchAlerts.isChecked = sessionManager.isAlertsEnabled()
        binding.switchAlerts.setOnCheckedChangeListener { _, checked ->
            sessionManager.setAlertsEnabled(checked)
        }

        // Logout
        binding.btnLogout.setOnClickListener {
            sessionManager.logout()
            startActivity(Intent(requireContext(), LoginActivity::class.java))
            requireActivity().finishAffinity()
        }

        // Load reservation history directly on profile
        db.reservationDao().getReservationsByUser(sessionManager.getUserId())
            .observe(viewLifecycleOwner) { reservations ->
                binding.reservationHistorySection.visibility = View.VISIBLE

                if (reservations.isEmpty()) {
                    binding.tvNoReservationHistory.visibility = View.VISIBLE
                    binding.rvReservationHistory.visibility   = View.GONE
                } else {
                    binding.tvNoReservationHistory.visibility = View.GONE
                    binding.rvReservationHistory.visibility   = View.VISIBLE

                    lifecycleScope.launch {
                        val combined = withContext(Dispatchers.IO) {
                            reservations.map { r ->
                                Pair(r, db.listingDao().getListingById(r.listingId))
                            }
                        }
                        val adapter = ProfileHistoryAdapter()
                        binding.rvReservationHistory.layoutManager =
                            LinearLayoutManager(requireContext())
                        binding.rvReservationHistory.adapter = adapter
                        binding.rvReservationHistory.isNestedScrollingEnabled = false
                        adapter.submitList(combined)
                    }
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    // Adapter for profile history (same card, same detail level as bookings tab)
    class ProfileHistoryAdapter :
        ListAdapter<Pair<Reservation, Listing?>, ProfileHistoryAdapter.VH>(DIFF) {

        companion object {
            val DIFF = object : DiffUtil.ItemCallback<Pair<Reservation, Listing?>>() {
                override fun areItemsTheSame(a: Pair<Reservation, Listing?>, b: Pair<Reservation, Listing?>) =
                    a.first.id == b.first.id
                override fun areContentsTheSame(a: Pair<Reservation, Listing?>, b: Pair<Reservation, Listing?>) =
                    a == b
            }
        }

        class VH(private val b: ItemReservationBinding) : RecyclerView.ViewHolder(b.root) {
            fun bind(r: Reservation, l: Listing?) {
                b.tvTitle.text         = r.listingTitle
                b.tvAmount.text        = "P${r.amount.toInt()} paid"
                b.tvStatus.text        = r.status
                b.tvPaymentMethod.text = r.paymentMethod.replace("_", " ")

                if (l != null) {
                    b.tvReference.text = "📍 ${l.location}, Gaborone  •  ${l.type}  •  ${l.distanceFromUB} from UB"
                    b.tvDate.text = "Check-in: ${r.checkInDate}\n" +
                        "Amenities: ${l.amenities.replace(",", " · ")}\n" +
                        "Booked: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(r.createdAt))}"
                } else {
                    b.tvReference.text = "Ref: ${r.referenceNumber}"
                    b.tvDate.text = "Check-in: ${r.checkInDate}\nBooked: " +
                        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(r.createdAt))
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemReservationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: VH, position: Int) {
            val (r, l) = getItem(position)
            holder.bind(r, l)
        }
    }
}
