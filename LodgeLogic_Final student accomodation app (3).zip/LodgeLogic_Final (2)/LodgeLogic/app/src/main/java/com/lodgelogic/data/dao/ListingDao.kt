package com.lodgelogic.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.lodgelogic.data.entities.Listing

@Dao
interface ListingDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(listing: Listing): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(listings: List<Listing>)

    @Update
    suspend fun update(listing: Listing)

    @Query("SELECT * FROM listings ORDER BY createdAt DESC")
    fun getAllListings(): LiveData<List<Listing>>

    @Query("SELECT * FROM listings WHERE isReserved = 0 ORDER BY createdAt DESC")
    fun getAvailableListings(): LiveData<List<Listing>>

    @Query("SELECT * FROM listings WHERE id = :id LIMIT 1")
    suspend fun getListingById(id: Int): Listing?

    @Query("""
        SELECT * FROM listings 
        WHERE (:location = '' OR location = :location)
        AND price <= :maxPrice
        AND price >= :minPrice
        AND (:type = '' OR type = :type)
        ORDER BY price ASC
    """)
    fun filterListings(
        location: String,
        minPrice: Double,
        maxPrice: Double,
        type: String
    ): LiveData<List<Listing>>

    @Query("UPDATE listings SET isReserved = 1, reservedByUserId = :userId WHERE id = :listingId")
    suspend fun reserveListing(listingId: Int, userId: Int)

    @Query("SELECT COUNT(*) FROM listings")
    suspend fun getListingCount(): Int

    @Query("SELECT * FROM listings WHERE landlordId = :landlordId")
    fun getListingsByLandlord(landlordId: Int): LiveData<List<Listing>>
}
