package com.lodgelogic.ui.chat

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.ChatMessage
import com.lodgelogic.databinding.ActivityChatBinding
import com.lodgelogic.databinding.ItemMessageReceivedBinding
import com.lodgelogic.databinding.ItemMessageSentBinding
import com.lodgelogic.utils.NotificationHelper
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ChatActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatBinding
    private lateinit var sessionManager: SessionManager
    private var landlordId   = -1
    private var landlordName = ""
    private var listingId    = -1
    private var listingTitle = ""
    private var greetingSent = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        landlordId   = intent.getIntExtra("landlord_id",   -1)
        landlordName = intent.getStringExtra("landlord_name")  ?: "Landlord"
        listingId    = intent.getIntExtra("listing_id",    -1)
        listingTitle = intent.getStringExtra("listing_title")  ?: ""

        val db = AppDatabase.getDatabase(this)

        binding.tvLandlordName.text = landlordName
        binding.tvListingTitle.text = listingTitle
        binding.btnBack.setOnClickListener { finish() }

        val chatAdapter = ChatAdapter(sessionManager.getUserId())
        val layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.rvMessages.layoutManager = layoutManager
        binding.rvMessages.adapter = chatAdapter

        db.chatDao().getConversationForListing(sessionManager.getUserId(), listingId)
            .observe(this) { messages ->
                chatAdapter.submitList(messages) {
                    if (messages.isNotEmpty())
                        binding.rvMessages.smoothScrollToPosition(messages.size - 1)
                }

                // Send automated landlord greeting only once when conversation is empty
                if (!greetingSent && messages.isEmpty()) {
                    greetingSent = true
                    Handler(Looper.getMainLooper()).postDelayed({
                        val greetings = listOf(
                            "Hello! 👋 Welcome to LodgeLogic. I'm $landlordName. How can I help you today?",
                            "Hi there! I'm $landlordName. Feel free to ask me anything about this property.",
                            "Good day! I'm $landlordName. I'm here to assist you with your accommodation needs."
                        )
                        lifecycleScope.launch {
                            db.chatDao().insert(
                                ChatMessage(
                                    senderId   = landlordId,
                                    receiverId = sessionManager.getUserId(),
                                    listingId  = listingId,
                                    message    = greetings.random()
                                )
                            )
                        }
                    }, 900L)
                }
            }

        binding.btnSend.setOnClickListener {
            val text = binding.etMessage.text.toString().trim()
            if (text.isEmpty()) return@setOnClickListener

            val myId = sessionManager.getUserId()
            binding.etMessage.setText("")

            lifecycleScope.launch {
                db.chatDao().insert(
                    ChatMessage(
                        senderId   = myId,
                        receiverId = landlordId,
                        listingId  = listingId,
                        message    = text
                    )
                )

                // Auto-reply: greetings get a greeting back, others get a property reply
                val lower = text.lowercase()
                val isGreeting = lower.contains("hi") || lower.contains("hello") ||
                    lower.contains("hey") || lower.contains("good day") ||
                    lower.contains("howdy") || lower.contains("greetings")

                delay(1500L)

                val reply = if (isGreeting) {
                    listOf(
                        "Hi! Great to hear from you 😊 How can I assist you with the listing?",
                        "Hello! Thanks for reaching out. What questions do you have about the property?",
                        "Hey there! Happy to help. Feel free to ask about the room or viewing times!"
                    ).random()
                } else {
                    listOf(
                        "Thank you for your interest! The room is still available.",
                        "Yes, the deposit confirms your booking. When would you like to move in?",
                        "I can arrange a viewing this Saturday. Does that work for you?",
                        "All utilities are included in the monthly rent.",
                        "Please send your student ID and I'll prepare the lease agreement.",
                        "The property is very close to public transport and UB campus."
                    ).random()
                }

                db.chatDao().insert(
                    ChatMessage(
                        senderId   = landlordId,
                        receiverId = myId,
                        listingId  = listingId,
                        message    = reply
                    )
                )
                NotificationHelper.showNewMessageNotification(this@ChatActivity, landlordName, reply)
            }
        }
    }

    // ── Adapter ──────────────────────────────────────────────────────────────

    class ChatAdapter(private val currentUserId: Int) :
        ListAdapter<ChatMessage, RecyclerView.ViewHolder>(DIFF) {

        companion object {
            private val DIFF = object : DiffUtil.ItemCallback<ChatMessage>() {
                override fun areItemsTheSame(a: ChatMessage, b: ChatMessage) = a.id == b.id
                override fun areContentsTheSame(a: ChatMessage, b: ChatMessage) = a == b
            }
        }

        override fun getItemViewType(position: Int) =
            if (getItem(position).senderId == currentUserId) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            if (viewType == 0)
                SentViewHolder(ItemMessageSentBinding.inflate(LayoutInflater.from(parent.context), parent, false))
            else
                ReceivedViewHolder(ItemMessageReceivedBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            val msg  = getItem(position)
            val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(msg.timestamp))
            when (holder) {
                is SentViewHolder     -> holder.bind(msg.message, time)
                is ReceivedViewHolder -> holder.bind(msg.message, time)
            }
        }

        class SentViewHolder(private val b: ItemMessageSentBinding) :
            RecyclerView.ViewHolder(b.root) {
            fun bind(message: String, time: String) { b.tvMessage.text = message; b.tvTime.text = time }
        }

        class ReceivedViewHolder(private val b: ItemMessageReceivedBinding) :
            RecyclerView.ViewHolder(b.root) {
            fun bind(message: String, time: String) { b.tvMessage.text = message; b.tvTime.text = time }
        }
    }
}
