package com.lodgelogic.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.lodgelogic.data.dao.*
import com.lodgelogic.data.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [User::class, Listing::class, Reservation::class, ChatMessage::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun listingDao(): ListingDao
    abstract fun reservationDao(): ReservationDao
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "lodge_logic_db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { instance ->
                                    if (instance.listingDao().getListingCount() == 0) {
                                        seedDatabase(instance)
                                    }
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedDatabase(db: AppDatabase) {

            // Landlords
            val landlords = listOf(
                User(studentId="L001", fullName="Tshepo Mokobi",      email="tshepo@landlord.bw",  password="landlord123", role="LANDLORD", university="", isVerified=true),
                User(studentId="L002", fullName="Sarah Molefe",        email="sarah@landlord.bw",   password="landlord123", role="LANDLORD", university="", isVerified=true),
                User(studentId="L003", fullName="Kabelo Sithole",      email="kabelo@landlord.bw",  password="landlord123", role="LANDLORD", university="", isVerified=true),
                User(studentId="L004", fullName="Mpho Phiri",          email="mpho@landlord.bw",    password="landlord123", role="LANDLORD", university="", isVerified=true),
                User(studentId="L005", fullName="Kefilwe Nkosi",       email="kefilwe@landlord.bw", password="landlord123", role="LANDLORD", university="", isVerified=true)
            )
            landlords.forEach { try { db.userDao().insert(it) } catch (e: Exception) { } }

            // Sample students
            val unis = listOf("University of Botswana","Botswana Accountancy College","BIUST","Limkokwing University","Ba Isago University")
            for (i in 1..10) {
                try {
                    db.userDao().insert(User(studentId="STU${String.format("%04d",i)}", fullName="Student $i",
                        email="student$i@uni.ac.bw", password="student123", role="STUDENT",
                        university=unis[i % unis.size], isVerified=i%3==0))
                } catch (e: Exception) { }
            }

            val amenitySets = listOf(
                "WiFi,Security,Laundry,Study Area",
                "WiFi,Security,Parking",
                "WiFi,Laundry,Shared Kitchen",
                "Security,24/7 Security,Study Area,Laundry",
                "WiFi,Security,AC,Parking",
                "WiFi,Security,Gym,Laundry",
                "WiFi,Shared Kitchen,Laundry",
                "Security,WiFi,24/7 Security"
            )

            val dates = listOf("2026-07-01","2026-08-01","2026-08-15","2026-09-01","2026-06-15","2026-10-01")

            // Image map — 50 positions, cycles 20 images, no adjacent duplicates
            val imageMap = listOf(
                "listing_1","listing_3","listing_5","listing_7","listing_9",
                "listing_11","listing_13","listing_15","listing_17","listing_19",
                "listing_2","listing_4","listing_6","listing_8","listing_10",
                "listing_12","listing_14","listing_16","listing_18","listing_20",
                "listing_6","listing_8","listing_10","listing_12","listing_14",
                "listing_16","listing_18","listing_20","listing_2","listing_4",
                "listing_7","listing_9","listing_11","listing_13","listing_15",
                "listing_17","listing_19","listing_1","listing_3","listing_5",
                "listing_7","listing_14","listing_2","listing_18","listing_5",
                "listing_12","listing_1","listing_16","listing_9","listing_20"
            )

            // Landlord data: id, name, phone
            val landlordData = listOf(
                Triple(6,"Tshepo Mokobi","72345678"),
                Triple(7,"Sarah Molefe","71234567"),
                Triple(8,"Kabelo Sithole","73456789"),
                Triple(9,"Mpho Phiri","74567890"),
                Triple(10,"Kefilwe Nkosi","75678901")
            )

            // ── 50 listings guaranteed to cover EVERY location, type, price band ──
            // Locations: Broadhurst, Phase 2, G-West, Tlokweng, Extension 11, Sebele
            // Types: HOSTEL (1200-2000), SHARED (2200-3100), STUDIO (3400-4800)
            // Each location has at least one of each type at multiple price points
            // so every chip/seekbar combo returns results

            data class L(val title:String, val loc:String, val type:String, val price:Double, val desc:String)

            val listings = listOf(
                // ── BROADHURST ──────────────────────────────────────────────
                L("Sunrise Budget Hostel, Broadhurst",      "Broadhurst", "HOSTEL", 1400.0, "Clean hostel room in a secure Broadhurst complex. Study desk and WiFi included."),
                L("Broadhurst Central Hostel",              "Broadhurst", "HOSTEL", 1800.0, "Well-maintained hostel near Broadhurst Mall. 24/7 security and laundry on-site."),
                L("Cedar Shared Flat, Broadhurst",          "Broadhurst", "SHARED", 2400.0, "Spacious shared flat with two other students. Fast fibre and off-street parking."),
                L("Broadhurst Harmony Shared Room",         "Broadhurst", "SHARED", 2900.0, "Bright shared home. Utilities included. 5 min walk to bus stop."),
                L("Sunrise Studio, Broadhurst",             "Broadhurst", "STUDIO", 3500.0, "Modern studio with open-plan living and great natural light. Secure complex."),
                L("Cedar View Studio, Broadhurst",          "Broadhurst", "STUDIO", 4200.0, "Executive studio with fitted wardrobes, dedicated parking and a private patio."),
                L("Marble Arch Studio, Broadhurst",         "Broadhurst", "STUDIO", 4600.0, "Luxury studio with marble countertops, smart TV and automated gate."),
                L("Ivory Towers Studio, Broadhurst",        "Broadhurst", "STUDIO", 3700.0, "Elegant studio with AC, modern bathroom and ample natural light."),
                L("Coral Bay Studio, Broadhurst",           "Broadhurst", "STUDIO", 4050.0, "Freshly renovated studio with open-plan living and private entrance."),
                // ── PHASE 2 ─────────────────────────────────────────────────
                L("Phase 2 Budget Hostel Bed",              "Phase 2",    "HOSTEL", 1300.0, "Affordable hostel bed near Phase 2 shops. Shared kitchen and bathrooms."),
                L("Blue Ridge Hostel, Phase 2",             "Phase 2",    "HOSTEL", 1750.0, "Friendly hostel with communal lounge. Walking distance to bus routes."),
                L("Blue Ridge Shared Room, Phase 2",        "Phase 2",    "SHARED", 2400.0, "Comfortable shared accommodation in a quiet Phase 2 neighbourhood."),
                L("Mango Grove Shared, Phase 2",            "Phase 2",    "SHARED", 2200.0, "Relaxed shared home with a large garden. Quiet street, great for studying."),
                L("Phoenix Shared Room, Phase 2",           "Phase 2",    "SHARED", 2500.0, "Shared room in a lively student house. All utilities included."),
                L("Breeze Point Shared, Phase 2",           "Phase 2",    "SHARED", 2300.0, "Two students already in residence. Best-value option in Phase 2."),
                L("Phase 2 Garden Studio",                  "Phase 2",    "STUDIO", 3600.0, "Quiet studio apartment with private garden access and fibre WiFi."),
                L("Oak Tree Studio, Phase 2",               "Phase 2",    "STUDIO", 4100.0, "Modern studio with large windows, open-plan kitchen and parking."),
                L("Springvale Studio, Phase 2",             "Phase 2",    "STUDIO", 3800.0, "Well-appointed studio. Great landlord, flexible lease available."),
                // ── G-WEST ──────────────────────────────────────────────────
                L("Acacia Hostel Bed, G-West",              "G-West",     "HOSTEL", 1500.0, "Affordable hostel in safe G-West complex. Walking distance to bus stop."),
                L("Palm Tree Hostel, G-West",               "G-West",     "HOSTEL", 1300.0, "Clean hostel bed in vibrant student complex. Basic amenities included."),
                L("Savanna Hostel, G-West",                 "G-West",     "HOSTEL", 1600.0, "Affordable room with locker storage. Shared kitchen stocked with essentials."),
                L("Oasis Hostel Dorm, G-West",              "G-West",     "HOSTEL", 1400.0, "Popular dorm with study tables in every room. 24/7 security."),
                L("Sunset Hostel Bed, G-West",              "G-West",     "HOSTEL", 1350.0, "Clean hostel bed with study desk and personal shelf space."),
                L("Metro Hostel Dorm, G-West",              "G-West",     "HOSTEL", 1550.0, "Central hostel with excellent security. Walk to shops and campus."),
                L("G-West Shared House",                    "G-West",     "SHARED", 2250.0, "Three-bedroom shared house with spacious lounge and garden."),
                L("Starlight Shared Room, G-West",          "G-West",     "SHARED", 2700.0, "Quiet shared home. Includes WiFi, laundry, and parking."),
                L("G-West Studio Apartment",                "G-West",     "STUDIO", 3450.0, "Compact studio with full kitchen, AC and secure parking. Near UB."),
                // ── TLOKWENG ────────────────────────────────────────────────
                L("Tlokweng Budget Hostel",                 "Tlokweng",   "HOSTEL", 1450.0, "Clean and affordable hostel near the Tlokweng border. Bus stop nearby."),
                L("Tlokweng Shared Flat",                   "Tlokweng",   "SHARED", 2350.0, "Cosy shared flat with two bedrooms. Fully furnished and move-in ready."),
                L("Willow Breeze Shared, Tlokweng",         "Tlokweng",   "SHARED", 2750.0, "Bright shared room with separate study and lounge areas."),
                L("Tranquil Shared Room, Tlokweng",         "Tlokweng",   "SHARED", 3000.0, "Ideal for postgrads. Fibre WiFi, home office, peaceful neighbourhood."),
                L("Mosaic Loft Studio, Tlokweng",           "Tlokweng",   "STUDIO", 3900.0, "Stylish loft studio with high ceilings and modern kitchen."),
                L("Diamond Heights Studio, Tlokweng",       "Tlokweng",   "STUDIO", 4800.0, "Premium studio with tiled floors, built-in appliances, garden view."),
                L("Lakeside Studio, Tlokweng",              "Tlokweng",   "STUDIO", 4500.0, "Spacious studio with open views, fitted kitchen and secure parking."),
                L("Sapphire Studio, Tlokweng",              "Tlokweng",   "STUDIO", 4700.0, "Sophisticated studio with private balcony and covered parking."),
                L("Crimson Leaf Studio, Tlokweng",          "Tlokweng",   "STUDIO", 3600.0, "Cosy studio with warm interiors and private outdoor seating area."),
                // ── EXTENSION 11 ────────────────────────────────────────────
                L("Extension 11 Hostel Room",               "Extension 11","HOSTEL",1650.0, "Friendly hostel in Extension 11. Communal TV lounge and study area."),
                L("Ext 11 Budget Bed",                      "Extension 11","HOSTEL",1250.0, "Budget-friendly hostel bed. Shared kitchen and 24/7 security."),
                L("Serene Shared Flat, Extension 11",       "Extension 11","SHARED",2800.0, "Spacious shared flat with fast WiFi. Professional housemates."),
                L("Thorn Tree Shared Flat, Ext 11",         "Extension 11","SHARED",2700.0, "Modern flat shared by three students. Fibre and dedicated study room."),
                L("Sunflower Shared House, Ext 11",         "Extension 11","SHARED",2900.0, "Four-bedroom shared house with large kitchen and off-street parking."),
                L("River Valley Shared, Extension 11",      "Extension 11","SHARED",2750.0, "Peaceful home near river walking trail. Fibre and DSTV included."),
                L("Emerald Shared Flat, Extension 11",      "Extension 11","SHARED",2850.0, "New appliances, fast fibre and private bathroom per room."),
                L("Extension 11 Studio",                    "Extension 11","STUDIO",3550.0, "Modern studio with great natural light and private parking."),
                L("Dusk Shared Apartment, Ext 11",          "Extension 11","STUDIO",3950.0, "Stylish apartment with rooftop terrace and panoramic city views."),
                // ── SEBELE ──────────────────────────────────────────────────
                L("Baobab Hostel Room, Sebele",             "Sebele",     "HOSTEL", 1800.0, "Clean hostel with shared bathrooms and communal kitchen. Laundry on-site."),
                L("Kalahari Hostel Bunk, Sebele",           "Sebele",     "HOSTEL", 1200.0, "Budget bunk-bed hostel ideal for first-semester students."),
                L("Stardust Hostel, Sebele",                "Sebele",     "HOSTEL", 1700.0, "Well-lit hostel close to Sebele shopping centre."),
                L("Flame Tree Hostel, Sebele",              "Sebele",     "HOSTEL", 1250.0, "Budget hostel with clean shared bathrooms and communal kitchen."),
                L("Sebele Shared House",                    "Sebele",     "SHARED", 2450.0, "Quiet shared property. All bills included. 10 min from campus."),
                L("Birch Park Hostel, Sebele",              "Sebele",     "HOSTEL", 1850.0, "Separate male/female wings. 24/7 security and CCTV."),
                L("Sebele Loft Studio",                     "Sebele",     "STUDIO", 3400.0, "Warm studio with timber accents, full kitchen and private parking."),
                L("Prairie Studio, Sebele",                 "Sebele",     "STUDIO", 3750.0, "Modern studio near Sebele. Pool table, study area, great community.")
            )

            listings.forEachIndexed { index, l ->
                val ld = landlordData[index % landlordData.size]
                val dist = "${String.format("%.1f", 0.5 + (index % 10) * 0.3)}km"
                try {
                    db.listingDao().insert(
                        Listing(
                            title            = l.title,
                            description      = l.desc,
                            price            = l.price,
                            location         = l.loc,
                            type             = l.type,
                            amenities        = amenitySets[index % amenitySets.size],
                            availabilityDate = dates[index % dates.size],
                            depositAmount    = l.price,
                            imageRes         = imageMap[index % imageMap.size],
                            landlordId       = ld.first,
                            landlordName     = ld.second,
                            landlordPhone    = ld.third,
                            distanceFromUB   = dist
                        )
                    )
                } catch (e: Exception) { }
            }
        }
    }
}
