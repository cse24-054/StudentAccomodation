package com.lodgelogic.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.lodgelogic.MainActivity
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.User
import com.lodgelogic.databinding.ActivityRegisterBinding
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.launch

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        db = AppDatabase.getDatabase(this)

        val universities = listOf(
            "University of Botswana",
            "Botswana Accountancy College",
            "BIUST",
            "Limkokwing University",
            "Ba Isago University"
        )
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, universities)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerUniversity.adapter = adapter

        binding.btnRegister.setOnClickListener { attemptRegister() }

        binding.tvSignIn.setOnClickListener { finish() }

        binding.btnBack.setOnClickListener { finish() }
    }

    private fun attemptRegister() {
        val fullName = binding.etFullName.text.toString().trim()
        val studentId = binding.etStudentId.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()
        val confirmPassword = binding.etConfirmPassword.text.toString().trim()
        val university = binding.spinnerUniversity.selectedItem.toString()

        if (fullName.isEmpty()) { binding.etFullName.error = "Name required"; return }
        if (studentId.isEmpty()) { binding.etStudentId.error = "Student ID required"; return }
        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.etEmail.error = "Valid email required"; return
        }
        if (password.length < 6) { binding.etPassword.error = "Min 6 characters"; return }
        if (password != confirmPassword) {
            binding.etConfirmPassword.error = "Passwords do not match"; return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnRegister.isEnabled = false

        lifecycleScope.launch {
            val existing = db.userDao().getUserByEmail(email)
            if (existing != null) {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    binding.btnRegister.isEnabled = true
                    binding.etEmail.error = "Email already registered"
                }
                return@launch
            }

            val user = User(
                studentId = studentId,
                fullName = fullName,
                email = email,
                password = password,
                university = university,
                role = "STUDENT"
            )
            val id = db.userDao().insert(user).toInt()

            runOnUiThread {
                binding.progressBar.visibility = View.GONE
                binding.btnRegister.isEnabled = true
                sessionManager.saveLogin(id, fullName, email, "STUDENT", studentId)
                Toast.makeText(this@RegisterActivity,
                    "Account created! Welcome, $fullName", Toast.LENGTH_SHORT).show()
                startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                finishAffinity()
            }
        }
    }
}
