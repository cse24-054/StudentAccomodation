package com.lodgelogic.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.R
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.databinding.ItemListingBinding

class ListingAdapter(private val onItemClick: (Listing) -> Unit) :
    ListAdapter<Listing, ListingAdapter.ListingViewHolder>(DIFF_CALLBACK) {

    companion object {

        private val DIFF_CALLBACK = object : DiffUtil.ItemCallback<Listing>() {
            override fun areItemsTheSame(oldItem: Listing, newItem: Listing) =
                oldItem.id == newItem.id
            override fun areContentsTheSame(oldItem: Listing, newItem: Listing) =
                oldItem == newItem
        }

        /**
         * Compile-time resource ID map — avoids getIdentifier() which can
         * silently return 0 for manually added .webp files at runtime.
         */
        fun resolveImageRes(imageRes: String): Int = when (imageRes) {
            "listing_1"  -> R.drawable.listing_1
            "listing_2"  -> R.drawable.listing_2
            "listing_3"  -> R.drawable.listing_3
            "listing_4"  -> R.drawable.listing_4
            "listing_5"  -> R.drawable.listing_5
            "listing_6"  -> R.drawable.listing_6
            "listing_7"  -> R.drawable.listing_7
            "listing_8"  -> R.drawable.listing_8
            "listing_9"  -> R.drawable.listing_9
            "listing_10" -> R.drawable.listing_10
            "listing_11" -> R.drawable.listing_11
            "listing_12" -> R.drawable.listing_12
            "listing_13" -> R.drawable.listing_13
            "listing_14" -> R.drawable.listing_14
            "listing_15" -> R.drawable.listing_15
            "listing_16" -> R.drawable.listing_16
            "listing_17" -> R.drawable.listing_17
            "listing_18" -> R.drawable.listing_18
            "listing_19" -> R.drawable.listing_19
            "listing_20" -> R.drawable.listing_20
            else         -> 0
        }
    }

    inner class ListingViewHolder(private val binding: ItemListingBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(listing: Listing) {
            binding.tvTitle.text    = listing.title
            binding.tvPrice.text    = "P${listing.price.toInt()}/mo"
            binding.tvLocation.text = "${listing.location}, Gaborone"
            binding.tvType.text     = listing.type

            val amenities = listing.amenities.split(",")
            binding.tvAmenities.text = amenities.take(2).joinToString(" · ")

            if (listing.isReserved) {
                binding.tvStatus.text = "Reserved"
                binding.tvStatus.setBackgroundResource(R.drawable.bg_badge_reserved)
            } else {
                binding.tvStatus.text = "Available"
                binding.tvStatus.setBackgroundResource(R.drawable.bg_badge_available)
            }

            // Use compile-time map — guaranteed to find the webp resource
            val resId = resolveImageRes(listing.imageRes)
            if (resId != 0) {
                binding.ivListing.setImageResource(resId)
            } else {
                // Only reaches here if imageRes string doesn't match any listing_N
                // Show the first available image rather than a color block
                binding.ivListing.setImageResource(R.drawable.listing_1)
            }

            binding.root.setOnClickListener { onItemClick(listing) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListingViewHolder {
        val binding = ItemListingBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ListingViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListingViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}
