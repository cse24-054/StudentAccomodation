package com.lodgelogic.ui.auth

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.lodgelogic.MainActivity
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.databinding.ActivityLoginBinding
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var sessionManager: SessionManager
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        db = AppDatabase.getDatabase(this)

        binding.btnSignIn.setOnClickListener { attemptLogin() }

        binding.tvCreateAccount.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }

        binding.btnGoogle.setOnClickListener {
            Toast.makeText(this, "Google Sign-In coming soon", Toast.LENGTH_SHORT).show()
        }

        binding.btnApple.setOnClickListener {
            Toast.makeText(this, "Apple Sign-In coming soon", Toast.LENGTH_SHORT).show()
        }

        binding.tvForgotPassword.setOnClickListener {
            Toast.makeText(this, "Password reset sent to your email", Toast.LENGTH_SHORT).show()
        }
    }

    private fun attemptLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        if (email.isEmpty()) {
            binding.etEmail.error = "Email or Student ID required"
            return
        }
        if (password.isEmpty()) {
            binding.etPassword.error = "Password required"
            return
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnSignIn.isEnabled = false

        lifecycleScope.launch {
            val user = db.userDao().login(email, password)
                ?: db.userDao().getUserByStudentId(email)?.takeIf { it.password == password }

            runOnUiThread {
                binding.progressBar.visibility = View.GONE
                binding.btnSignIn.isEnabled = true

                if (user != null) {
                    sessionManager.saveLogin(
                        user.id, user.fullName, user.email,
                        user.role, user.studentId
                    )
                    startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                    finish()
                } else {
                    Toast.makeText(this@LoginActivity,
                        "Invalid credentials. Please try again.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
