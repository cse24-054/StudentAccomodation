package com.lodgelogic.ui.reservation

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.data.entities.Reservation
import com.lodgelogic.databinding.FragmentBookingsBinding
import com.lodgelogic.databinding.ItemReservationBinding
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class BookingsFragment : Fragment() {

    private var _binding: FragmentBookingsBinding? = null
    private val binding get() = _binding!!

    data class ReservationWithListing(val reservation: Reservation, val listing: Listing?)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentBookingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val sessionManager = SessionManager(requireContext())
        val db = AppDatabase.getDatabase(requireContext())

        val adapter = ReservationAdapter()
        binding.rvReservations.layoutManager = LinearLayoutManager(requireContext())
        binding.rvReservations.adapter = adapter

        db.reservationDao().getReservationsByUser(sessionManager.getUserId())
            .observe(viewLifecycleOwner) { reservations ->
                binding.tvEmpty.visibility =
                    if (reservations.isEmpty()) View.VISIBLE else View.GONE

                lifecycleScope.launch {
                    val combined = withContext(Dispatchers.IO) {
                        reservations.map { r ->
                            ReservationWithListing(r, db.listingDao().getListingById(r.listingId))
                        }
                    }
                    adapter.submitList(combined)
                }
            }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    class ReservationAdapter :
        ListAdapter<ReservationWithListing, ReservationAdapter.ViewHolder>(DIFF) {

        companion object {
            private val DIFF = object : DiffUtil.ItemCallback<ReservationWithListing>() {
                override fun areItemsTheSame(a: ReservationWithListing, b: ReservationWithListing) =
                    a.reservation.id == b.reservation.id
                override fun areContentsTheSame(a: ReservationWithListing, b: ReservationWithListing) =
                    a == b
            }
        }

        class ViewHolder(private val b: ItemReservationBinding) :
            RecyclerView.ViewHolder(b.root) {
            fun bind(item: ReservationWithListing) {
                val r = item.reservation
                val l = item.listing

                b.tvTitle.text         = r.listingTitle
                b.tvAmount.text        = "P${r.amount.toInt()} paid"
                b.tvStatus.text        = r.status
                b.tvPaymentMethod.text = r.paymentMethod.replace("_", " ")

                if (l != null) {
                    // Location + type + distance
                    b.tvReference.text = "📍 ${l.location}, Gaborone  •  ${l.type}  •  ${l.distanceFromUB} from UB"
                    // Check-in + amenities + booking date
                    b.tvDate.text = "Check-in: ${r.checkInDate}\n" +
                        "Amenities: ${l.amenities.replace(",", " · ")}\n" +
                        "Booked: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(r.createdAt))}"
                } else {
                    b.tvReference.text = "Ref: ${r.referenceNumber}"
                    b.tvDate.text = "Booked: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(r.createdAt))}"
                }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            ViewHolder(ItemReservationBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: ViewHolder, position: Int) =
            holder.bind(getItem(position))
    }
}
