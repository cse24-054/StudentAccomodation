package com.lodgelogic.ui.reservation

import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.data.entities.Reservation
import com.lodgelogic.databinding.ActivityReservationBinding
import com.lodgelogic.utils.NotificationHelper
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class ReservationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityReservationBinding
    private lateinit var sessionManager: SessionManager
    private var listing: Listing? = null
    private var selectedPaymentMethod = "WALLET"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityReservationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        val db = AppDatabase.getDatabase(this)
        val listingId = intent.getIntExtra("listing_id", -1)

        if (listingId == -1) { finish(); return }

        lifecycleScope.launch {
            listing = db.listingDao().getListingById(listingId)
            runOnUiThread { listing?.let { displayReservation(it, db) } }
        }
    }

    private fun displayReservation(l: Listing, db: AppDatabase) {
        binding.tvLodgeName.text = l.title
        binding.tvAmount.text = "P${String.format("%.2f", l.depositAmount)}"

        val walletBalance = sessionManager.getWalletBalance()
        binding.tvWalletBalance.text = "Balance: P${String.format("%.2f", walletBalance)}"

        binding.cardWallet.setOnClickListener {
            selectedPaymentMethod = "WALLET"
            binding.cardWallet.strokeWidth = 4
            binding.cardMobileMoney.strokeWidth = 0
            binding.ivWalletCheck.visibility = View.VISIBLE
            binding.ivMobileCheck.visibility = View.GONE
        }

        binding.cardMobileMoney.setOnClickListener {
            selectedPaymentMethod = "MOBILE_MONEY"
            binding.cardMobileMoney.strokeWidth = 4
            binding.cardWallet.strokeWidth = 0
            binding.ivMobileCheck.visibility = View.VISIBLE
            binding.ivWalletCheck.visibility = View.GONE
        }

        binding.btnPayNow.setOnClickListener {
            processPayment(l, db)
        }
    }

    private fun processPayment(l: Listing, db: AppDatabase) {
        if (selectedPaymentMethod == "WALLET") {
            val balance = sessionManager.getWalletBalance()
            if (balance < l.depositAmount) {
                Toast.makeText(this, "Insufficient wallet balance", Toast.LENGTH_LONG).show()
                return
            }
        }

        binding.progressBar.visibility = View.VISIBLE
        binding.btnPayNow.isEnabled = false

        lifecycleScope.launch {
            val current = db.listingDao().getListingById(l.id)
            if (current?.isReserved == true) {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    binding.btnPayNow.isEnabled = true
                    Toast.makeText(this@ReservationActivity,
                        "Sorry, this room was just reserved by another student.",
                        Toast.LENGTH_LONG).show()
                    finish()
                }
                return@launch
            }

            val ref = "LL-${System.currentTimeMillis().toString().takeLast(8)}"
            val reservation = Reservation(
                userId          = sessionManager.getUserId(),
                listingId       = l.id,
                listingTitle    = l.title,
                amount          = l.depositAmount,
                paymentMethod   = selectedPaymentMethod,
                referenceNumber = ref,
                checkInDate     = l.availabilityDate
            )
            db.reservationDao().insert(reservation)
            db.listingDao().reserveListing(l.id, sessionManager.getUserId())

            if (selectedPaymentMethod == "WALLET") {
                sessionManager.deductFromWallet(l.depositAmount)
            }

            NotificationHelper.showReservationConfirmation(this@ReservationActivity, l.title, ref)

            runOnUiThread {
                binding.progressBar.visibility = View.GONE
                showBeautifulSuccessDialog(l, ref)
            }
        }
    }

    private fun showBeautifulSuccessDialog(l: Listing, ref: String) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(false)

        val date = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        val payLabel = if (selectedPaymentMethod == "WALLET") "Student Wallet" else "Mobile Money"

        // Root container
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        // ── Green header ──────────────────────────────────────────────────────
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#1B5E20"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setPadding(32, 52, 32, 44)
        }
        header.addView(TextView(this).apply {
            text = "🏠"
            textSize = 46f
            gravity = Gravity.CENTER
        })
        header.addView(TextView(this).apply {
            text = "Reservation Confirmed!"
            textSize = 21f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 4)
        })
        header.addView(TextView(this).apply {
            text = "✓  Your booking is secured"
            textSize = 13f
            setTextColor(Color.parseColor("#A5D6A7"))
            gravity = Gravity.CENTER
        })

        // ── Details body ─────────────────────────────────────────────────────
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            setPadding(44, 28, 44, 8)
        }

        fun row(label: String, value: String, valueColor: Int = Color.parseColor("#1C1C1E")) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.setMargins(0, 0, 0, 16) }
            }
            row.addView(TextView(this).apply {
                text = label
                textSize = 13f
                setTextColor(Color.parseColor("#757575"))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(TextView(this).apply {
                text = value
                textSize = 13f
                setTextColor(valueColor)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.END
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.2f)
            })
            body.addView(row)
        }

        val shortTitle = if (l.title.length > 28) l.title.take(28) + "…" else l.title
        row("🏡  Property", shortTitle)
        row("📍  Location", "${l.location}, Gaborone")
        row("🏷️  Type", l.type)
        row("💰  Amount Paid", "P${l.depositAmount.toInt()}", Color.parseColor("#1B5E20"))
        row("💳  Payment", payLabel)
        row("📅  Date", date)

        // Divider
        body.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#E0E0E0"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 1).also { it.setMargins(0, 4, 0, 16) }
        })
        row("🔖  Reference", ref, Color.parseColor("#1565C0"))

        // Note
        val note = TextView(this).apply {
            text = "The landlord has been notified.\nCheck My Bookings for full details."
            textSize = 12f
            setTextColor(Color.parseColor("#9E9E9E"))
            gravity = Gravity.CENTER
            setPadding(44, 4, 44, 20)
        }

        // ── View Bookings button ──────────────────────────────────────────────
        val btn = TextView(this).apply {
            text = "VIEW MY BOOKINGS"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setBackgroundColor(Color.parseColor("#1565C0"))
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 128)
            setOnClickListener { dialog.dismiss(); finish() }
        }

        root.addView(header)
        root.addView(body)
        root.addView(note)
        root.addView(btn)

        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                (resources.displayMetrics.widthPixels * 0.91).toInt(),
                WindowManager.LayoutParams.WRAP_CONTENT
            )
            setGravity(Gravity.CENTER)
        }
        dialog.show()
    }
}
