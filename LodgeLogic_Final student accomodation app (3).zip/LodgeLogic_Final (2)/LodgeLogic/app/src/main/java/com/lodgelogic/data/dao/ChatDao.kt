package com.lodgelogic.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.lodgelogic.data.entities.ChatMessage

@Dao
interface ChatDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessage): Long

    @Query("""
        SELECT * FROM chat_messages 
        WHERE (senderId = :userId AND receiverId = :otherId)
        OR (senderId = :otherId AND receiverId = :userId)
        ORDER BY timestamp ASC
    """)
    fun getConversation(userId: Int, otherId: Int): LiveData<List<ChatMessage>>

    @Query("""
        SELECT * FROM chat_messages 
        WHERE (senderId = :userId OR receiverId = :userId)
        AND listingId = :listingId
        ORDER BY timestamp ASC
    """)
    fun getConversationForListing(userId: Int, listingId: Int): LiveData<List<ChatMessage>>

    @Query("UPDATE chat_messages SET isRead = 1 WHERE receiverId = :userId")
    suspend fun markAllRead(userId: Int)

    @Query("SELECT COUNT(*) FROM chat_messages WHERE receiverId = :userId AND isRead = 0")
    fun getUnreadCount(userId: Int): LiveData<Int>

    @Query("""
        SELECT DISTINCT senderId FROM chat_messages WHERE receiverId = :userId
        UNION
        SELECT DISTINCT receiverId FROM chat_messages WHERE senderId = :userId
    """)
    suspend fun getConversationPartnerIds(userId: Int): List<Int>
}
