package com.lodgelogic.ui.alerts

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import com.lodgelogic.databinding.FragmentAlertsBinding
import com.lodgelogic.utils.SessionManager

class AlertsFragment : Fragment() {

    private var _binding: FragmentAlertsBinding? = null
    private val binding get() = _binding!!
    private lateinit var sessionManager: SessionManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAlertsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        sessionManager = SessionManager(requireContext())

        // Load saved preferences
        binding.switchAlerts.isChecked = sessionManager.isAlertsEnabled()
        binding.tvPrefLocation.text    = sessionManager.getPrefLocation().ifEmpty { "Any location" }
        binding.seekBarMinPrice.progress = ((sessionManager.getPrefMinPrice() - 1000) / 10).toInt().coerceIn(0, 400)
        binding.seekBarMaxPrice.progress = ((sessionManager.getPrefMaxPrice() - 1000) / 10).toInt().coerceIn(0, 400)
        updatePriceLabels()

        // Alerts toggle
        binding.switchAlerts.setOnCheckedChangeListener { _, checked ->
            sessionManager.setAlertsEnabled(checked)
            binding.alertsContent.visibility = if (checked) View.VISIBLE else View.GONE
        }
        binding.alertsContent.visibility =
            if (sessionManager.isAlertsEnabled()) View.VISIBLE else View.GONE

        // Location chips
        val locationChips = mapOf(
            binding.chipAnyLocation  to "",
            binding.chipBroadhurst  to "Broadhurst",
            binding.chipPhase2      to "Phase 2",
            binding.chipGWest       to "G-West",
            binding.chipTlokweng    to "Tlokweng",
            binding.chipExt11       to "Extension 11",
            binding.chipSebele      to "Sebele"
        )
        val savedLoc = sessionManager.getPrefLocation()
        locationChips.forEach { (chip, loc) -> chip.isChecked = (loc == savedLoc) }

        locationChips.forEach { (chip, loc) ->
            chip.setOnClickListener {
                locationChips.keys.forEach { it.isChecked = false }
                chip.isChecked = true
                binding.tvPrefLocation.text = loc.ifEmpty { "Any location" }
                savePreferences()
            }
        }

        // Type chips
        val typeChips = mapOf(
            binding.chipAnyType to "",
            binding.chipHostel  to "HOSTEL",
            binding.chipStudio  to "STUDIO",
            binding.chipShared  to "SHARED"
        )
        typeChips[binding.chipAnyType]?.let { }
        binding.chipAnyType.isChecked = true

        typeChips.forEach { (chip, _) ->
            chip.setOnClickListener {
                typeChips.keys.forEach { it.isChecked = false }
                chip.isChecked = true
                savePreferences()
            }
        }

        // Price seekbars
        binding.seekBarMinPrice.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { updatePriceLabels() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { savePreferences() }
        })
        binding.seekBarMaxPrice.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, user: Boolean) { updatePriceLabels() }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { savePreferences() }
        })

        // Save button
        binding.btnSaveAlerts.setOnClickListener {
            savePreferences()
            binding.tvSavedConfirm.visibility = View.VISIBLE
            binding.tvSavedConfirm.animate().alpha(1f).setDuration(300).withEndAction {
                binding.tvSavedConfirm.animate().alpha(0f).setStartDelay(1500).setDuration(500)
                    .withEndAction { binding.tvSavedConfirm.visibility = View.GONE }.start()
            }.start()
        }
    }

    private fun updatePriceLabels() {
        val min = 1000 + binding.seekBarMinPrice.progress * 10
        val max = 1000 + binding.seekBarMaxPrice.progress * 10
        binding.tvMinPrice.text = "P$min"
        binding.tvMaxPrice.text = "P$max"
    }

    private fun savePreferences() {
        val min = (1000 + binding.seekBarMinPrice.progress * 10).toDouble()
        val max = (1000 + binding.seekBarMaxPrice.progress * 10).toDouble()
        val loc = when {
            binding.chipBroadhurst.isChecked -> "Broadhurst"
            binding.chipPhase2.isChecked     -> "Phase 2"
            binding.chipGWest.isChecked      -> "G-West"
            binding.chipTlokweng.isChecked   -> "Tlokweng"
            binding.chipExt11.isChecked      -> "Extension 11"
            binding.chipSebele.isChecked     -> "Sebele"
            else                             -> ""
        }
        sessionManager.saveSearchPreferences(loc, min, max)
        sessionManager.setAlertsEnabled(binding.switchAlerts.isChecked)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
