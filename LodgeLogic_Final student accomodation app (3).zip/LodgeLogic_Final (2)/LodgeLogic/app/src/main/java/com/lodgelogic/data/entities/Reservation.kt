package com.lodgelogic.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reservations")
data class Reservation(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val userId: Int,
    val listingId: Int,
    val listingTitle: String,
    val amount: Double,
    val paymentMethod: String,  // WALLET, MOBILE_MONEY
    val referenceNumber: String,
    val status: String = "RESERVED", // RESERVED, COMPLETED, CANCELLED
    val checkInDate: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
