package com.lodgelogic.ui.search

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.databinding.FragmentSearchBinding
import com.lodgelogic.ui.home.ListingAdapter
import com.lodgelogic.ui.listing.ListingDetailActivity
import com.lodgelogic.utils.SessionManager

class SearchFragment : Fragment() {

    private var _binding: FragmentSearchBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ListingAdapter
    private var selectedLocation = ""
    private var selectedType = ""
    private var maxPrice = 5000.0
    private val minPrice = 1000.0

    companion object {
        fun newInstance(location: String = "") = SearchFragment().apply {
            arguments = Bundle().apply { putString("location", location) }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSearchBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val db = AppDatabase.getDatabase(requireContext())

        arguments?.getString("location")?.takeIf { it.isNotEmpty() }?.let {
            selectedLocation = it
            highlightLocationChip(it)
        }

        binding.rvResults.layoutManager = LinearLayoutManager(requireContext())
        adapter = ListingAdapter { listing ->
            startActivity(
                Intent(requireContext(), ListingDetailActivity::class.java)
                    .putExtra("listing_id", listing.id)
            )
        }
        binding.rvResults.adapter = adapter

        // Price SeekBar — releases on stop tracking to reduce filter calls
        binding.seekBarPrice.max = 4000
        binding.seekBarPrice.progress = 4000
        binding.tvPriceRange.text = "P5,000"
        binding.seekBarPrice.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                maxPrice = (1000 + p).toDouble()
                binding.tvPriceRange.text = "P${maxPrice.toInt()}"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { applyFilters(db) }
        })

        // Location chips
        binding.chipBroadhurst.setOnClickListener { toggleLocation("Broadhurst"); applyFilters(db) }
        binding.chipPhase2.setOnClickListener     { toggleLocation("Phase 2");    applyFilters(db) }
        binding.chipGWest.setOnClickListener      { toggleLocation("G-West");     applyFilters(db) }
        binding.chipTlokweng.setOnClickListener   { toggleLocation("Tlokweng");   applyFilters(db) }
        binding.chipExt11.setOnClickListener      { toggleLocation("Extension 11"); applyFilters(db) }
        binding.chipSebele.setOnClickListener     { toggleLocation("Sebele");     applyFilters(db) }

        // Type chips
        binding.chipHostel.setOnClickListener { toggleType("HOSTEL"); applyFilters(db) }
        binding.chipStudio.setOnClickListener { toggleType("STUDIO"); applyFilters(db) }
        binding.chipShared.setOnClickListener { toggleType("SHARED"); applyFilters(db) }

        applyFilters(db)
    }

    private fun toggleLocation(loc: String) {
        selectedLocation = if (selectedLocation == loc) "" else loc
        highlightLocationChip(selectedLocation)
    }

    private fun highlightLocationChip(location: String) {
        binding.chipBroadhurst.isChecked = location == "Broadhurst"
        binding.chipPhase2.isChecked     = location == "Phase 2"
        binding.chipGWest.isChecked      = location == "G-West"
        binding.chipTlokweng.isChecked   = location == "Tlokweng"
        binding.chipExt11.isChecked      = location == "Extension 11"
        binding.chipSebele.isChecked     = location == "Sebele"
    }

    private fun toggleType(type: String) {
        selectedType = if (selectedType == type) "" else type
        binding.chipHostel.isChecked = selectedType == "HOSTEL"
        binding.chipStudio.isChecked = selectedType == "STUDIO"
        binding.chipShared.isChecked = selectedType == "SHARED"
    }

    private fun applyFilters(db: AppDatabase) {
        db.listingDao().filterListings(
            location = selectedLocation,
            minPrice = minPrice,
            maxPrice = maxPrice,
            type     = selectedType
        ).observe(viewLifecycleOwner) { listings ->
            adapter.submitList(listings)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
