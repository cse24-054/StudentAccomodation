package com.lodgelogic.ui.listing

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.lodgelogic.R
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.data.entities.Listing
import com.lodgelogic.databinding.ActivityListingDetailBinding
import com.lodgelogic.ui.chat.ChatActivity
import com.lodgelogic.ui.reservation.ReservationActivity
import com.lodgelogic.utils.SessionManager
import kotlinx.coroutines.launch

class ListingDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListingDetailBinding
    private lateinit var sessionManager: SessionManager
    private var listing: Listing? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListingDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        sessionManager = SessionManager(this)
        val db = AppDatabase.getDatabase(this)
        val listingId = intent.getIntExtra("listing_id", -1)

        binding.btnBack.setOnClickListener { finish() }

        if (listingId == -1) { finish(); return }

        lifecycleScope.launch {
            listing = db.listingDao().getListingById(listingId)
            runOnUiThread { listing?.let { displayListing(it) } }
        }
    }

    private fun displayListing(l: Listing) {
        binding.tvTitle.text = l.title
        binding.tvPrice.text = "P${l.price.toInt()}"
        binding.tvLocation.text = "${l.location}, Gaborone"
        binding.tvAvailability.text = "From ${l.availabilityDate}"
        binding.tvDeposit.text = "Deposit: P${l.depositAmount.toInt()}"
        binding.tvDescription.text = l.description
        binding.tvDistance.text = "${l.distanceFromUB} from University of Botswana"
        binding.tvLandlord.text = l.landlordName

        // Amenities
        val amenities = l.amenities.split(",")
        binding.tvAmenities.text = amenities.joinToString("\n") { "✓ $it" }

        // Image
        val imageRes = com.lodgelogic.ui.home.ListingAdapter.resolveImageRes(l.imageRes).takeIf { it != 0 } ?: when (l.type) {
            "STUDIO" -> R.drawable.placeholder_studio
            "SHARED" -> R.drawable.placeholder_shared
            else -> R.drawable.placeholder_hostel
        }
        binding.ivListing.setImageResource(imageRes)

        // Badge
        if (l.isReserved) {
            binding.tvVerified.text = "Reserved"
            binding.tvVerified.setBackgroundResource(R.drawable.bg_badge_reserved)
            binding.btnPayReserve.text = "Room Unavailable"
            binding.btnPayReserve.isEnabled = false
        } else {
            binding.tvVerified.text = "Verified Listing"
            binding.btnPayReserve.setOnClickListener {
                val intent = Intent(this, ReservationActivity::class.java)
                intent.putExtra("listing_id", l.id)
                startActivity(intent)
            }
        }

        // Chat button
        binding.btnChat.setOnClickListener {
            val intent = Intent(this, ChatActivity::class.java)
            intent.putExtra("landlord_id", l.landlordId)
            intent.putExtra("landlord_name", l.landlordName)
            intent.putExtra("listing_id", l.id)
            intent.putExtra("listing_title", l.title)
            startActivity(intent)
        }
    }
}
