package com.lodgelogic.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import com.lodgelogic.R
import com.lodgelogic.data.entities.Listing

object NotificationHelper {

    private const val CHANNEL_ID   = "lodge_logic_alerts"
    private const val CHANNEL_NAME = "Lodge Logic Alerts"

    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Alerts for matching accommodation listings" }
            context.getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(channel)
        }
    }

    fun showListingMatchNotification(context: Context, listing: Listing) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("New Matching Listing Found!")
            .setContentText("${listing.title} in ${listing.location} — P${listing.price.toInt()}/mo")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "${listing.title} in ${listing.location} at P${listing.price.toInt()}/month " +
                    "matches your saved preferences."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(listing.id, notification)
    }

    fun showReservationConfirmation(context: Context, listingTitle: String, reference: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Reservation Confirmed!")
            .setContentText("$listingTitle — Ref: $reference")
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "Your reservation for $listingTitle has been confirmed. Reference: $reference."
                )
            )
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
    }

    fun showNewMessageNotification(context: Context, senderName: String, message: String) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("New message from $senderName")
            .setContentText(message)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()
        nm.notify(System.currentTimeMillis().toInt(), notification)
    }
}
