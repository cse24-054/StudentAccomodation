package com.lodgelogic.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.lodgelogic.data.entities.Reservation

@Dao
interface ReservationDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(reservation: Reservation): Long

    @Update
    suspend fun update(reservation: Reservation)

    @Query("SELECT * FROM reservations WHERE userId = :userId ORDER BY createdAt DESC")
    fun getReservationsByUser(userId: Int): LiveData<List<Reservation>>

    @Query("SELECT * FROM reservations WHERE listingId = :listingId LIMIT 1")
    suspend fun getReservationByListing(listingId: Int): Reservation?

    @Query("SELECT * FROM reservations WHERE referenceNumber = :ref LIMIT 1")
    suspend fun getByReference(ref: String): Reservation?

    @Query("SELECT COUNT(*) FROM reservations WHERE userId = :userId")
    suspend fun getCountByUser(userId: Int): Int
}
