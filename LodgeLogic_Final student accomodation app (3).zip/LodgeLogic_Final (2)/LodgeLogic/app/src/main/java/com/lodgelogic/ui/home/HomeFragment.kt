package com.lodgelogic.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.lodgelogic.R
import com.lodgelogic.data.database.AppDatabase
import com.lodgelogic.databinding.FragmentHomeBinding
import com.lodgelogic.ui.listing.ListingDetailActivity

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ListingAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sessionManager = com.lodgelogic.utils.SessionManager(requireContext())
        val db = AppDatabase.getDatabase(requireContext())

        val firstName = sessionManager.getUserName().split(" ").firstOrNull() ?: "Student"
        binding.tvGreeting.text = "Find your space in\nGaborone."
        binding.tvSubtitle.text = "Welcome back, $firstName"

        adapter = ListingAdapter { listing ->
            val intent = Intent(requireContext(), ListingDetailActivity::class.java)
            intent.putExtra("listing_id", listing.id)
            startActivity(intent)
        }
        binding.rvFeaturedListings.adapter = adapter

        db.listingDao().getAvailableListings().observe(viewLifecycleOwner) { listings ->
            adapter.submitList(listings.take(6))
        }

        binding.etLocation.setOnClickListener {
            findNavController().navigate(R.id.searchFragment)
        }
        binding.btnSearch.setOnClickListener {
            findNavController().navigate(R.id.searchFragment)
        }

        binding.chipMainMall.setOnClickListener  { navigateToSearch("Main Mall")    }
        binding.chipBlock6.setOnClickListener    { navigateToSearch("Block 6")      }
        binding.chipTlokweng.setOnClickListener  { navigateToSearch("Tlokweng")     }
        binding.chipPhase2.setOnClickListener    { navigateToSearch("Phase 2")      }
    }

    private fun navigateToSearch(location: String) {
        val bundle = Bundle().apply { putString("location", location) }
        findNavController().navigate(R.id.searchFragment, bundle)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
