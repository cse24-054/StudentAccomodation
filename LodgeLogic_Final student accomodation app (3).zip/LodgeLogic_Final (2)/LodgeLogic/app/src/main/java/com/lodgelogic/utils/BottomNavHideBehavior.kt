package com.lodgelogic.utils

import android.content.Context
import android.util.AttributeSet
import android.view.View
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.ViewCompat

class BottomNavHideBehavior(context: Context, attrs: AttributeSet) :
    CoordinatorLayout.Behavior<View>(context, attrs) {

    override fun onStartNestedScroll(
        coordinatorLayout: CoordinatorLayout, child: View,
        directTargetChild: View, target: View, axes: Int, type: Int
    ) = (axes and ViewCompat.SCROLL_AXIS_VERTICAL) != 0

    override fun onNestedScroll(
        coordinatorLayout: CoordinatorLayout, child: View, target: View,
        dxConsumed: Int, dyConsumed: Int, dxUnconsumed: Int, dyUnconsumed: Int,
        type: Int, consumed: IntArray
    ) {
        if (dyConsumed > 0) {
            // Scrolling down — hide the nav bar
            child.animate()
                .translationY(child.height.toFloat())
                .setDuration(200)
                .start()
        } else if (dyConsumed < 0) {
            // Scrolling up — show the nav bar
            child.animate()
                .translationY(0f)
                .setDuration(200)
                .start()
        }
    }
}
