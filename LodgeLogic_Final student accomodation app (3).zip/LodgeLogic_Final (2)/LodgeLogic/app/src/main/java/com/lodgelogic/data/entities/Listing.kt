package com.lodgelogic.data.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "listings")
data class Listing(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val title: String,
    val description: String,
    val price: Double,
    val location: String,       // e.g. "Tlokweng", "Phase 2", "Block 6"
    val type: String,           // HOSTEL, STUDIO, SHARED
    val amenities: String,      // comma-separated: "WiFi,Security,Laundry"
    val availabilityDate: String, // "2024-08-01"
    val depositAmount: Double,
    val imageRes: String,       // drawable resource name or URI
    val landlordId: Int,
    val landlordName: String,
    val landlordPhone: String = "",
    val distanceFromUB: String = "",  // e.g. "1.2km"
    val isReserved: Boolean = false,
    val reservedByUserId: Int = -1,
    val createdAt: Long = System.currentTimeMillis()
)
